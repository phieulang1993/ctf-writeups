#!/bin/sh
#

timeout 60 /home/pivot/pivot
