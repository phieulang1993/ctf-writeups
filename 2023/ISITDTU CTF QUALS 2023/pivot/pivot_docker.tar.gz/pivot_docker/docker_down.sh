sudo docker-compose down
